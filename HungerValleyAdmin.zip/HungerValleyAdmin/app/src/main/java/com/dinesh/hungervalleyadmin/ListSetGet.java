package com.dinesh.hungervalleyadmin;

public class ListSetGet {

    String Status;
    public ListSetGet() {

    }

    public ListSetGet(String status) {
        Status = status;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
